Beste Jos en Elfriede,

Hierbij de resultaten van Sprint 1. 
Het Sprint 1 verslag staat in de inlevermap.
Stappen om dit project werkend te krijgen:
1. Open dit project in Eclipse als Java project
2. Voeg als external library de mysql-connector-java-5.1.30-bin toe uit de hoofdmap
3. Initialiseer de database met de Initialise Database.sql in de hoofdmap
4. Build het project met Ant
5. Start Tomcat op
6. Ga naar index.html van het project
Als het goed is werkt alles nu :)
